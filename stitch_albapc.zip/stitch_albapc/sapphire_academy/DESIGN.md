```markdown
# Design System Strategy: The Curated Interface

## 1. Overview & Creative North Star: "The Digital Mentor"
This design system moves away from the sterile, "template" look of traditional LMS platforms. Our Creative North Star is **The Digital Mentor**—an experience that feels as authoritative as a private tutor and as fluid as a premium editorial magazine. 

We achieve this through **Intentional Asymmetry** and **Tonal Depth**. Instead of a rigid, boxed grid, we use expansive white space and overlapping elements to create a sense of movement. The interface should feel like it is breathing, guiding the student’s eye through a narrative rather than a list of tasks. We break the "Standard UI" mold by replacing harsh lines with soft tonal shifts and "Glassmorphism" to evoke a sense of modern, high-end technology.

---

## 2. Colors & Surface Philosophy
The palette utilizes a deep foundation of Navy (`primary`) balanced by the clarity of Japanese-inspired neutrals (`surface`).

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section content. Boundaries must be defined solely through background color shifts or subtle tonal transitions. For example, a `surface-container-low` section sitting on a `surface` background provides enough contrast to define a zone without the visual clutter of a line.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of frosted glass.
- **Base Layer:** `surface` (#f7f9fb)
- **Content Zones:** `surface-container-low` (#f2f4f6)
- **Interactive Cards:** `surface-container-lowest` (#ffffff)
- **Active Overlays:** `surface-container-high` (#e6e8ea)

### The "Glass & Gradient" Rule
To ensure the platform feels bespoke, use Glassmorphism for floating elements (like the 'teaching pointer' feedback or navigation tooltips). Use a `40% opacity` version of `surface-container-lowest` with a `blur(12px)` backdrop filter. 
*Signature Polish:* Main CTAs should use a subtle linear gradient from `primary` (#022448) to `primary-container` (#1E3A5F) at a 135-degree angle to provide "visual soul."

---

## 3. Typography: The Editorial Voice
We use **Plus Jakarta Sans** to provide a geometric, modern energy for English text, paired with the precision of **Hiragino Sans** for Japanese.

- **Display Scales (`display-lg` to `display-sm`):** Used for course titles and hero moments. These should feel authoritative. Use `primary` color for these to anchor the page.
- **Headline & Title Scales:** Designed for lesson headers. Use tight letter-spacing (-0.02em) to give a premium, "printed" feel.
- **Body & Label Scales:** Prioritize readability. `body-md` is our workhorse. Ensure `line-height` is set to 1.6 for long-form Japanese text to prevent eye fatigue.

The hierarchy is "Top-Heavy": large, bold headers contrasted with significantly smaller, elegantly spaced labels (`label-md`). This contrast is what creates the "High-End Editorial" look.

---

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to create "pop"; we use them to create "atmosphere."

- **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift. No shadow required.
- **Ambient Shadows:** For floating elements (Modals/Popovers), use a shadow tinted with `on-surface` (#191c1e). 
    * *Specs:* `0px 10px 30px rgba(25, 28, 30, 0.06)`.
- **The "Ghost Border" Fallback:** If a container absolutely requires a border for accessibility, use `outline-variant` at **15% opacity**. Never use 100% opaque borders.
- **The Teaching Pointer:** The custom cursor is a low-poly or minimalist hand icon. When hovering over interactive elements, the cursor should trigger a subtle `surface-tint` glow behind it, emphasizing the "teaching" aspect.

---

## 5. Components
Our components are defined by the **Roundedness Scale** (primarily `md` 0.75rem and `lg` 1rem).

### Buttons & Chips
- **Primary Button:** Gradient fill (`primary` to `primary-container`), `xl` roundedness, white text. No shadow.
- **Interactive Quiz Strips:** These use `tertiary-fixed` (#d2e4ff) backgrounds with `on-tertiary-container` text. They should span the full width of the container to act as a "break" in the editorial flow.
- **Status Badges:** 
    - *Completed:* `secondary-container` with `on-secondary-container`.
    - *Locked:* `surface-dim` with `outline` icon.
    - *Coming Soon:* `primary-fixed` with `on-primary-fixed`.

### Progress Bars
Avoid thin lines. Use a "Thick-to-Thin" style. The track is `surface-container-highest` (height: 8px), and the indicator is a `secondary` blue (height: 8px) with `full` roundedness.

### Cards & Lists
**Constraint:** Absolute prohibition of divider lines.
- Separate list items using `8px` of vertical white space (`spacing-2`).
- To group items, wrap them in a `surface-container-low` card with an `lg` (1rem) corner radius.

---

## 6. Do's and Don'ts

### Do:
- **Use "Breathing Room":** Use `spacing-12` (3rem) or `spacing-16` (4rem) between major sections to let the high-end typography stand out.
- **Layer for Importance:** Place the most critical information on the "highest" (lightest) surface.
- **Respect the Script:** When mixing English and Japanese, ensure the Japanese text is 10% larger than the English to maintain visual parity in weight.

### Don't:
- **No 1px Outlines:** Do not "box in" your content. Let the background colors do the work.
- **No "Heavy" Shadows:** Avoid the default Material Design shadows. They are too aggressive for this "clean and modern" aesthetic.
- **No Harsh Corners:** Avoid the `none` or `sm` roundedness tokens for main UI containers. Everything must feel approachable and "soft-modern."

---

## 7. Interaction Design
- **Teaching Pointer Movement:** The custom hand cursor should have a slight lag (spring physics) to feel organic.
- **State Transitions:** All hover states (cards, buttons) should transition over `200ms` using an `ease-out` curve. Instead of shifting color drastically, increase the `surface-container` tier by one level (e.g., from `low` to `lowest`).