# Design System Specification

## 1. Overview & Creative North Star: "The Illuminated Archive"
This design system moves away from the "disposable" feel of standard ed-tech platforms. Our Creative North Star is **The Illuminated Archive**—an experience that feels as authoritative as a physical library but as fluid as a modern editorial magazine. 

We break the "standard template" by utilizing intentional white space (Ma/間), high-contrast typographic scales, and tonal layering. The interface should feel like a series of sophisticated, stacked surfaces that guide the learner's eye through a clear hierarchy of information. We avoid the rigid "grid-of-boxes" look in favor of an asymmetrical, breathable layout that prioritizes focus and cognitive ease.

---

## 2. Colors & Surface Logic

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections, cards, or containers. Boundaries must be defined solely through background color shifts or subtle tonal transitions. For example, a `surface-container-low` card sitting on a `surface` background creates a natural edge without the visual noise of a stroke.

### Surface Hierarchy & Nesting
We treat the UI as a series of physical layers. Use the `surface-container` tiers to create depth:
*   **Base Layer:** `surface` (#f8f9fa) – Used for the primary background.
*   **Lowered Depth:** `surface_container_low` (#f3f4f5) – Used for secondary content areas or background sectioning.
*   **Elevated Content:** `surface_container_lowest` (#ffffff) – Used for primary content cards and active quiz elements to make them "pop" against the grey base.
*   **The Sidebar Monolith:** Use `primary` (#005396) or `on_primary_fixed_variant` (#004883) for the sidebar to create a heavy, grounding anchor for the navigation.

### The "Glass & Gradient" Rule
To elevate the experience beyond flat design:
*   **Floating Elements:** Use `surface_container_lowest` with 80% opacity and a `12px` backdrop-blur for floating progress indicators or mobile navigation.
*   **Signature Textures:** Apply a subtle linear gradient (from `primary` to `primary_container`) on main CTAs and hero headers. This provides a "soul" to the digital surface that a flat hex code cannot achieve.

---

## 3. Typography: The Editorial Rhythm
The typography balances the geometric precision of **Plus Jakarta Sans** with the functional clarity of **Hiragino Sans**.

*   **Display & Headline (Plus Jakarta Sans):** Use `display-lg` and `headline-lg` for chapter titles and major milestones. These should be set with tighter letter-spacing (-0.02em) to feel like a high-end magazine.
*   **Body & Labels (Inter / Hiragino Sans):** For Japanese text, ensure a line-height of at least `1.7` to accommodate complex characters. `body-lg` is the standard for lesson content, providing maximum readability for long-form educational text.
*   **Hierarchy as Identity:** Use `label-sm` in all-caps with `0.05em` letter-spacing for overlines (e.g., "MODULE 01") to create an academic, categorized feel.

---

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to simulate "height" in a traditional sense. We use **Tonal Layering**.

*   **The Layering Principle:** Depth is achieved by "stacking." Place a `surface_container_lowest` card on a `surface_container_high` section to create a soft, natural lift.
*   **Ambient Shadows:** If a shadow is absolutely required for a floating modal, use a highly diffused blur (`24px` to `40px`) at `4%` opacity, tinted with the `on_surface` color. It should feel like a soft glow of light, not a dark drop shadow.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility (e.g., in high-contrast modes), use the `outline_variant` token at **20% opacity**. Never use 100% opaque borders.

---

## 5. Components

### Sidebar (The Navigation Anchor)
*   **Background:** `on_primary_fixed_variant` (#004883).
*   **State:** When collapsed, show only icons with `primary_fixed_dim` coloring.
*   **Interaction:** Use a `0.3s` ease-in-out transition for the width expansion. No borders; use a subtle shadow on the right edge if it overlaps content.

### Content Cards & Quiz Elements
*   **Structure:** No borders. Use `surface_container_lowest` (#ffffff) for the card body.
*   **Quiz Options:** Default state is `surface_container_low`. Hover state is `secondary_fixed`. The "Selected" state should use a `primary_container` background with `on_primary_container` text.
*   **Success Feedback:** Use `tertiary_container` (#2a7848) with a soft `surface_bright` inner glow for correct answers.

### Buttons
*   **Primary:** Gradient from `primary` to `primary_container`. Shape: `xl` (0.75rem) for a modern, approachable feel.
*   **Secondary:** `surface_container_high` background with `on_surface` text. No border.
*   **Tertiary/Ghost:** No background. Use `primary` text.

### Progress Indicators
*   **Track:** `surface_variant`.
*   **Indicator:** `tertiary` (#055f31).
*   **Detail:** Add a subtle "shimmer" animation to active progress bars to indicate "learning in progress."

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical white space. Leave one side of a layout significantly more open than the other to create "Ma" (negative space).
*   **Do** use `surface_container` tiers to group related educational topics instead of divider lines.
*   **Do** prioritize Japanese legibility by ensuring `Hiragino Sans` is the primary fallback for all CJK characters.

### Don’t:
*   **Don't** use 1px solid borders. This is the quickest way to make the design feel "template-like."
*   **Don't** use pure black (#000000) for text. Use `on_surface` (#191c1d) to maintain a premium, soft-contrast look.
*   **Don't** crowd the quiz interface. Each question should have at least `spacing-12` of vertical breathing room.
*   **Don't** use harsh shadows. If the element doesn't look elevated through color alone, re-evaluate your surface hierarchy.